totalinfor
load('ARGMAT.mat');
load('Arg_Data.mat');

all=ArgData;
yy=unique(ArgData.Year);
ele=unique(ArgData.Element);
area=unique(ArgData.Area);
item=unique(ArgData.Item);
IndexLevel_eqsu=[ 1   7 1/2 1/2;
                 1/7  1 1/8 1/9;
                  2   8  1   2;
                  2   9  1/2 1;];

for j=1:5              
    for i=1:1:145
        FoodIndex(i,j)=calIndex(IndexLevel_eqsu,A(i,2:10,j));
    end
end

for j=1:5
    for i=1:1:145
        FoodDiv(i,j)=exp(length(find(data(j,2,i,:)~=-1))/length(item))-log10(nanvar(data(j,3,i,find(data(j,3,i,:)~=-1))));
    end
    FoodDiv(:,j)=rscore(FoodDiv(:,j),1);
end

for j=1:5
    for i=1:1:length(A(:,1,1))
    A(i,11,j)=FoodIndex(i,j);
    A(i,12,j)=FoodDiv(i,j);
    end
end
A(118,:,:)=[];
country(118+1)=[];
for i=1:1:length(country)-1
    A(i,13,1)=waterstress.Value((i-1)*5+1);
    A(i,13,2)=waterstress.Value((i-1)*5+2);
    A(i,13,3)=waterstress.Value((i-1)*5+3);
    A(i,13,4)=waterstress.Value((i-1)*5+4);
    A(i,13,5)=waterstress.Value((i-1)*5+5);
end

for  i=1:5
    A(:,13,i)=rscore(A(:,13,i),2);
end

B=A(:,:,5);
filename='modeified.xlsx';
for i=1:5
    xlswrite(filename,A(:,:,i),i,'A1:M145');
end