clear all
clc
%% ���õ���ѡ���������
opts = spreadsheetImportOptions("NumVariables", 95);

% ָ���������ͷ�Χ
opts.Sheet = "Sheet1";
opts.DataRange = "A2:CQ1162";

% ָ�������ƺ�����
opts.VariableNames = ["CountryName", "NBII", "SeriesName", "YR2015", "YR2016", "YR2017", "YR2018", "YR2019", "YEAR", "C1SecurityApparatus", "C2FactionalizedElites", "C3GroupGrievance", "E1Economy", "E2EconomicInequality", "E3HumanFlightandBrainDrain", "P1StateLegitimacy", "P2PublicServices", "P3HumanRights", "S1DemographicPressures", "S2RefugeesandIDPS", "X1ExternalIntervention", "Total", "YEAR1", "C1SecurityApparatus1", "C2FactionalizedElites1", "C3GroupGrievance1", "E1Economy1", "E2EconomicInequality1", "E3HumanFlightandBrainDrain1", "P1StateLegitimacy1", "P2PublicServices1", "P3HumanRights1", "S1DemographicPressures1", "S2RefugeesandIDPs", "X1ExternalIntervention1", "Total1", "YEAR2", "C1SecurityApparatus2", "C2FactionalizedElites2", "C3GroupGrievance2", "E1Economy2", "E2EconomicInequality2", "E3HumanFlightandBrainDrain2", "P1StateLegitimacy2", "P2PublicServices2", "P3HumanRights2", "S1DemographicPressures2", "S2RefugeesandIDPs1", "X1ExternalIntervention2", "Total2", "YEAR3", "C1SecurityApparatus3", "C2FactionalizedElites3", "C3GroupGrievance3", "E1Economy3", "E2EconomicInequality3", "E3HumanFlightandBrainDrain3", "P1StateLegitimacy3", "P2PublicServices3", "P3HumanRights3", "S1DemographicPressures3", "S2RefugeesandIDPs2", "X1ExternalIntervention3", "Total3", "YEAR4", "C1SecurityApparatus4", "C2FactionalizedElites4", "C3GroupGrievance4", "E1Economy4", "E2EconomicInequality4", "E3HumanFlightandBrainDrain4", "P1StateLegitimacy4", "P2PublicServices4", "P3HumanRights4", "S1DemographicPressures4", "S2RefugeesandIDPs3", "X1ExternalIntervention4", "Total4", "Magnitudeoftheeffect", "Deaths", "YEAR5", "EPIScore", "YearPercentChange", "YEAR6", "EPIScore1", "YearPercentChange1", "YEAR7", "EPIScore2", "YEAR8", "EPIScore3", "YEAR9", "EPIScore4", "VarName93", "VarName94", "VarName95"];
opts.VariableTypes = ["string", "double", "categorical", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "string", "string", "double"];

% ָ����������
opts = setvaropts(opts, ["CountryName", "VarName93", "VarName94"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["CountryName", "SeriesName", "VarName93", "VarName94"], "EmptyFieldRule", "auto");

% ��������
totalInfor = readtable("C:\Users\26582\Desktop\SrcData��1��[2730]\totalInfor.xlsx", opts, "UseExcel", false);


% �����ʱ����
clear opts

%% table reforming
% Normalization 

country=unique(totalInfor.CountryName);
% A(:,1,1)=country(2:end,1);
% A(:,1,2)=country(2:end,1);
% A(:,1,3)=country(2:end,1);
% A(:,1,4)=country(2:end,1);
% A(:,1,5)=country(2:end,1);length(A(:,1,1))
for i=1:1:length(country)-1
    A(i,2:7,1)=totalInfor.YR2015((i-1)*6+1:6*i);
    A(i,2:7,2)=totalInfor.YR2016((i-1)*6+1:6*i);
    A(i,2:7,3)=totalInfor.YR2017((i-1)*6+1:6*i);
    A(i,2:7,4)=totalInfor.YR2018((i-1)*6+1:6*i);
    A(i,2:7,5)=totalInfor.YR2019((i-1)*6+1:6*i);
    A(i,8,:)=totalInfor.NBII((i-1)*6+1);
    A(i,9,1)=totalInfor.Total((i-1)*6+1);
    A(i,9,2)=totalInfor.Total1((i-1)*6+1);
    A(i,9,3)=totalInfor.Total2((i-1)*6+1);
    A(i,9,4)=totalInfor.Total3((i-1)*6+1);
    A(i,9,5)=totalInfor.Total4((i-1)*6+1);
    A(i,10,1)=totalInfor.EPIScore((i-1)*6+1);
    A(i,10,2)=totalInfor.EPIScore1((i-1)*6+1);
    A(i,10,3)=totalInfor.EPIScore2((i-1)*6+1);
    A(i,10,4)=totalInfor.EPIScore3((i-1)*6+1);
    A(i,10,5)=totalInfor.EPIScore4((i-1)*6+1);
end
flag=[1,1,1,2,2,1,1,2,1];
for j=1:5
    for i=2:1:10
    A(:,i,j)=rscore(A(:,i,j),flag(i-1));
    end
end
A=fillmissing(A,'constant',0);