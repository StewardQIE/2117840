function [RD,CD,order]=optics(x,k)
% Input: 
% x - data set (m,n); m-objects, n-variables
% k - number of objects in a neighborhood of the selected object
% (minimal number of objects considered as a cluster)
% -------------------------------------------------------------------------
% Output: 
% RD - vector with reachability distances (m,1)
% CD - vector with core distances (m,1)
% order - vector specifying the order of objects (1,m)
% -------------------------------------------------------------------------

[m,~]=size(x);
CD=zeros(1,m);%Core Distance
RD=ones(1,m)*10^10;% Reachable Distance
 
% Calculate Core Distances
for i=1:m   
    D=sort(dist(x(i,:),x));
    CD(i)=D(k);  
end
order=[];
seeds=[1:m];
ind=1;
while ~isempty(seeds)
    ob=seeds(ind);      
    seeds(ind)=[] ;
    order=[order ob];
    mm=max([ones(1,length(seeds))*CD(ob);dist(x(ob,:),x(seeds,:))]);
    ii=(RD(seeds))>mm;
    RD(seeds(ii))=mm(ii);
    [~, ind]=min(RD(seeds));
end   
 
%RD(1)=max(RD(2:m))+.1*max(RD(2:m));
kk=RD>k;
RD(kk)=10;
figure
plot(RD(order))
function [D]=dist(i,x)
% Calculates the Euclidean distances between the i-th object and all objects in x    

[m,n]=size(x);
D=(sum((((ones(m,1)*i)-x).^2)'));
D=sqrt(D);
if n==1
   D=abs((ones(m,1)*i-x))';
end