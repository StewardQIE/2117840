load('Arg_Data.mat');

all=ArgData;
yy=unique(ArgData.Year);
ele=unique(ArgData.Element);
area=unique(ArgData.Area);
item=unique(ArgData.Item);

% for p=1:1:length(yy)
%     for q=1:1:length(ele)
%         for m=1:1:length(area)
%             for n=1:1:length(item)
%                 if isempty(find((ArgData.Year==yy(p))&(ArgData.Element==ele(q))&(ArgData.Area==area(m))&(ArgData.Item==item(n))))
%                 data(p,q,m,n)=-1;
%                 else
%                 data(p,q,m,n)=ArgData.Value(find((ArgData.Year==yy(p))&(ArgData.Element==ele(q))&(ArgData.Area==area(m))&(ArgData.Item==item(n))));
%                 end
%             end
%         end
%     end
% end

developed={'United States of America','Denmark'};
developing={'China','Egypt'};
%data(yy,element,area,item)
flag_ed=1;
flag_ing=1;
for p=1:1:length(yy)
    AreaHarvestedDev(p,:)=data(p,1,find(area==developed{flag_ed}),find(data(p,1,find(area==developed{flag_ed}),:)~=-1));
    [B,IAHDev]=maxk(data(p,1,find(area==developed{flag_ed}),:),3);
    ProductionDev(p,:)=data(p,2,find(area==developed{flag_ed}),find(data(p,2,find(area==developed{flag_ed}),:)~=-1));
    [B,IProDev]=maxk(data(p,2,find(area==developed{flag_ed}),:),3);
    YieldDev(p,:)=data(p,3,find(area==developed{flag_ed}),find(data(p,3,find(area==developed{flag_ed}),:)~=-1));
    [B,IYDev]=maxk(data(p,3,find(area==developed{flag_ed}),:),3);
    AreaHarvestedIng(p,:)=data(p,1,find(area==developing{flag_ing}),find(data(p,1,find(area==developing{flag_ing}),:)~=-1));
    [B,IAHIng]=maxk(data(p,1,find(area==developing{flag_ing}),:),3);
    ProductionIng(p,:)=data(p,2,find(area==developing{flag_ing}),find(data(p,2,find(area==developing{flag_ing}),:)~=-1));
    [B,IProIng]=maxk(data(p,2,find(area==developing{flag_ing}),:),3);
    YieldIng(p,:)=data(p,3,find(area==developing{flag_ing}),find(data(p,3,find(area==developing{flag_ing}),:)~=-1));
    [B,IYIng]=maxk(data(p,3,find(area==developing{flag_ing}),:),3);
end

figure(1)
subplot(3,1,1)
bar(AreaHarvestedDev,'stacked');
title(['Area Harvested for' developed{flag_ed}]);
xticklabels(num2str(yy))
legend(item(IAHDev));
subplot(3,1,2)
bar(ProductionDev,'stacked');
title(['Production for' developed{flag_ed}]);
xticklabels(num2str(yy))
legend(item(IProDev));
subplot(3,1,3)
bar(YieldDev,'stacked');
title(['Yield for' developed{flag_ed}]);
xticklabels(num2str(yy))
legend(item(IYDev));

figure(2)
subplot(3,1,1)
bar(AreaHarvestedIng,'stacked');
title(['Area Harvested for' developing{flag_ing}]);
xticklabels(num2str(yy))
legend(item(IAHIng));
subplot(3,1,2)
bar(ProductionIng,'stacked');
title(['Production for' developing{flag_ing}]);
xticklabels(num2str(yy))
legend(item(IProIng));
subplot(3,1,3)
bar(YieldIng,'stacked');
title(['Yield for' developing{flag_ing}]);
xticklabels(num2str(yy))
legend(item(IYIng));