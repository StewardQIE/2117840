function FoodIndex=calIndex(IndexLevel,InforMAT)
%% Use to calculate the weightmatrix.
% IndexLevel indicates four criterions: efficiency, profitability, sustainability, and equity.
%           [efficiency, profitability, sustainability, and equity]
% Importance for 1-9. Aij=i_index/j_index
        
Supply=[0.233,0.3,0.233,0.233];
Transport=[0.3,0.3,0.3,0.1];
Consumer=[0.217,0.15,0.22,0.367];
NatureRes=[0.25,0.25,0.25,0.25];

IndexIndicator=[Supply;Supply;
                Supply;Transport;
                NatureRes;NatureRes;NatureRes;Transport;NatureRes];

[W, ~, ~, CR]=AHP(IndexLevel);
[~,w]=size(InforMAT);
[hind,~]=size(IndexIndicator);
    if CR<0.1
        if w==hind
            FoodIndex=W'*IndexIndicator'* InforMAT';
        else error('Input matrix demesion wrong');
        end
    else error('Worng IndexLevel');
    end
end