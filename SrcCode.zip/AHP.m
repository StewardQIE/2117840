function [W, Lmax, CI, CR] = AHP(A)

[V,D] = eig(A);
[Lmax,ind] = max(diag(D));
W = V(:,ind) / sum(V(:,ind)); 
Lmax = mean((A * W) ./ W); 
n = size(A, 1);
CI = (Lmax - n) / (n - 1);       
% Saaty
RI = [0 0 0.58 0.90 1.12 1.24 1.32 1.41 1.45 1.49 1.51]; 
CR = CI / RI(n); 