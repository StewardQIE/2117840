%----------------------------Source Code for MCM/ICM 2021 Problem E--------------------------------%
Copy Right(s)

This is the code package for MCM/ICM 2021 Problem E. 

Totally, 21 files inside of this package. Here is the description of each file:

1. '*.csv, *.xlsx' -- 6 files, data file
Arg_Data.csv  -- The source data from FAO about argriculture data. Area harvesting, yeilds, production data for 146 coutries and 161 type of crops is included. Time interval is 2000-2019.

FoodBalance.csv  -- The reformed data from FAO about food balance.

FoodSecurit.csv  -- The reformed data from FAO about food security.

waterstress.xlsx  -- The reformed data from FAO about the water strees.

modeified.xlsx, exe.xlsx -- The bulk of output data.

2. '*.mat'  -- 4 files, Matlab data
111.mat  -- Temporay data file for Matlab.

Arg_Data.mat  -- Corresponding to Arg_Data.csv data in Matlab.

ARGMAT.mat  -- The intra Matlab data file. Food Index is stored.

final.mat  -- All the intra, input and output data used in Matlab is included.

3.  '*.m' --10 files, Matlab code
AHP.m  -- Impelmentation of AHP in Matlab. 

argdatasum.m -- Reading and process the Arg_Data.mat. Using a 4-D matrix to store the results.

calIndex.m  -- The food index calculator.

fooddiv.m  -- The food diversity calculator.

main.m  -- Main enterence of this program.

optics.m  -- OPTICS impelmentation.

rscore.m  --Entropy weight method impelmentation.

totalinfor.m --To read and total 15 indicators.
